#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include<arpa/inet.h> //inet_addr


int client(int portno, const char *hostname)
{
    int sockfd, n;
    struct sockaddr_in serv_addr;
    char buffer[1000];

    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd < 0)
        printf("ERROR opening socket");

    bzero((char *) &serv_addr, sizeof(serv_addr));
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_addr.s_addr = inet_addr(hostname);
    serv_addr.sin_port = htons( portno );


    if (connect(sockfd,(struct sockaddr *) &serv_addr,sizeof(serv_addr)) < 0)
        printf("ERROR connecting");

     int i=0;
     for (i=0 ; i< 5 ; i++) {
        printf("Digite a mensagem:\n");
        gets(buffer);
        n = send(sockfd,buffer,strlen(buffer),0);
        if (n < 0)
             printf("ERROR writing to socket\n");
        bzero(buffer,256);
    }

    n = recv(sockfd,buffer,255, 0);
    //buffer[3] = 123;
    if (n < 0)
         printf("ERROR reading from socket\n");
    printf("_%s_\n",buffer);
    close(sockfd);
    return 0;
}
