#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>

void server(int portno) {
     int sockfd, newsockfd;
     socklen_t clilen;
     char buffer[256];
     struct sockaddr_in serv_addr, cli_addr;
     int n;

     sockfd = socket(AF_INET, SOCK_STREAM, 0);
     if (sockfd < 0)
        printf("ERROR opening socket\n");
     bzero((char *) &serv_addr, sizeof(serv_addr));
     serv_addr.sin_family = AF_INET;
     serv_addr.sin_addr.s_addr = INADDR_ANY;
     serv_addr.sin_port = htons(portno);
     if (bind(sockfd, (struct sockaddr *) &serv_addr,
              sizeof(serv_addr)) < 0)
              printf("ERROR on binding\n");
    printf("Aguardando conexao na porta %d\n", portno);
     listen(sockfd,5);
     clilen = sizeof(cli_addr);
     newsockfd = accept(sockfd,  (struct sockaddr *) &cli_addr,  &clilen);
     if (newsockfd < 0)
          printf("ERROR on accept\n");

     int i=0;
     for (i=0 ; i< 5 ; i++) {
         bzero(buffer,256);
         n = recv(newsockfd,buffer,255, 0);
         if (n < 0) printf("ERROR reading from socket\n");
         printf("Messagem recebida: %s\n",buffer);
     }

    char retorno[] = "Fim do recebimento!";
    retorno[19] = 'a';

     n = send(newsockfd,retorno, 1000, 0);
     if (n < 0) printf("ERROR writing to socket\n");
     close(newsockfd);
     close(sockfd);
}
